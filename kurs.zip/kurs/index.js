const express = require('express')
const MongoClient= require('mongodb').MongoClient;
const port = 8000
const objectId = require("mongodb").ObjectId;
const bodyParser = require("body-parser")
const app = express()
const jsonParser = express.json();

app.use(express.static(__dirname + '/public'))
var urlencodedParser = bodyParser.urlencoded({ extended: false })
const mongoClient = new MongoClient("mongodb+srv://olenkaivanova08:Ivanova1976@cluster0.mb9ms.mongodb.net/");


mongoClient.connect(function(err, client) {
    if (err) return console.log(err);
    const db = client.db("kurs");
    app.locals.librarys = db.collection("Library");
    app.locals.books = db.collection("Books");
    app.locals.readers = db.collection("Readers");
    app.listen(port, function() {
        console.log("Server has been started...");
    });
});

app.get("/api/librarys", function(req, res){
        
    const librarys = req.app.locals.librarys;
    librarys.find({}).toArray(function(err, Library){
         
        if(err) return console.log(err);
        res.send(Library)
    })
});
app.get("/api/books", function(req, res){
        
    const books = req.app.locals.books;
    books.find({}).toArray(function(err, Books){
         
        if(err) return console.log(err);
        res.send(Books)
    })
});

app.get("/api/readers", function(req, res){
        
    const readers = req.app.locals.readers;
    readers.find({}).toArray(function(err, Readers){
         
        if(err) return console.log(err);
        res.send(Readers)
    })
});


app.post("/api/librarys", urlencodedParser, function(req, res) {



    if (!req.body) return res.sendStatus(400);
        const name = req.body.nameLib;
        const telephone = req.body.telephone;
        const emps = [{ "name": req.body.name, "place_of_work": req.body.place_of_work, "num_room": objectId()}];

    
        const Library = {
            name: name,
            telephone: telephone,
            emps:emps,
        };
    
        const collection = req.app.locals.librarys;
        collection.insertOne(Library, function(err, result) {
            if (err) return console.log(err);
            res.send(Library);
        });
});

app.post("/api/books", urlencodedParser, function(req, res) {



    if (!req.body) return res.sendStatus(400);
        const title = req.body.title;
        const first_name = req.body.first_name;
        const last_name = req.body.last_name;
        const instances = [{ "_id": objectId(),"type": req.body.type, "category": req.body.category,"date_of_receipt" : new Date(req.body.date_of_receipt),
        "date_of_debiting": new Date(req.body.date_of_debiting),"read_room": objectId(req.body.read_room),"place":req.body.place, "row":req.body.row, "shelf":req.body.shelf,"status":req.body.status}];
        const Books = {
            title:title,
            firs_name: first_name,
            last_name: last_name,
            instances: instances,
        };
    
        const collection = req.app.locals.books;
        collection.insertOne(Books, function(err, result) {
            if (err) return console.log(err);
            res.send(Books);
        });
});

app.post("/api/readers", urlencodedParser, function(req, res) {



    if (!req.body) return res.sendStatus(400);
        const first_name = req.body.first_name;
        const last_name = req.body.last_name;
        const category = req.body.category;
        const library= objectId(req.body.library);
        const list_of_literature = [{ "book_name": req.body.book_name,"author_name": req.body.author_name, "author_surname": req.body.author_surname,"start_date" : new Date(req.body.start_date),
        "back_date": new Date(req.body.back_date),"end_date": new Date(req.body.end_date)}];

        const Readers = {
            firs_name: first_name,
            last_name: last_name,
            category: category,
            library:library,
            list_of_literature:list_of_literature   
        };
    
        const collection = req.app.locals.readers;
        collection.insertOne(Readers, function(err, result) {
            if (err) return console.log(err);
            res.send(Readers);
        });
});







